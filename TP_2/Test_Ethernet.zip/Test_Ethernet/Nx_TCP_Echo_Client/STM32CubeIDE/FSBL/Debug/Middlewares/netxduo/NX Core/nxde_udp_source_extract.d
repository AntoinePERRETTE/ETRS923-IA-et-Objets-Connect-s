Middlewares/netxduo/NX Core/nxde_udp_source_extract.o: \
 /home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Middlewares/ST/netxduo/common/src/nxde_udp_source_extract.c \
 ../../../Middlewares/ST/netxduo/common/inc/nx_api.h \
 ../../../Middlewares/ST/threadx/ports/cortex_m55/gnu/inc/tx_port.h \
 ../../../FSBL/Core/Inc/tx_user.h \
 ../../../Middlewares/ST/threadx/common/inc/tx_api.h \
 ../../../Middlewares/ST/netxduo/ports/cortex_m55/gnu/inc/nx_port.h \
 ../../../FSBL/NetXDuo/App/nx_user.h \
 ../../../Middlewares/ST/threadx/common/inc/tx_trace.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_udp.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_api.h
../../../Middlewares/ST/netxduo/common/inc/nx_api.h:
../../../Middlewares/ST/threadx/ports/cortex_m55/gnu/inc/tx_port.h:
../../../FSBL/Core/Inc/tx_user.h:
../../../Middlewares/ST/threadx/common/inc/tx_api.h:
../../../Middlewares/ST/netxduo/ports/cortex_m55/gnu/inc/nx_port.h:
../../../FSBL/NetXDuo/App/nx_user.h:
../../../Middlewares/ST/threadx/common/inc/tx_trace.h:
../../../Middlewares/ST/netxduo/common/inc/nx_udp.h:
../../../Middlewares/ST/netxduo/common/inc/nx_api.h:
