Middlewares/netxduo/NX Core/nx_ipv6_process_routing_option.o: \
 /home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Middlewares/ST/netxduo/common/src/nx_ipv6_process_routing_option.c \
 ../../../Middlewares/ST/netxduo/common/inc/nx_api.h \
 ../../../Middlewares/ST/threadx/ports/cortex_m55/gnu/inc/tx_port.h \
 ../../../FSBL/Core/Inc/tx_user.h \
 ../../../Middlewares/ST/threadx/common/inc/tx_api.h \
 ../../../Middlewares/ST/netxduo/ports/cortex_m55/gnu/inc/nx_port.h \
 ../../../FSBL/NetXDuo/App/nx_user.h \
 ../../../Middlewares/ST/threadx/common/inc/tx_trace.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_ipv6.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_api.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_icmpv6.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_nd_cache.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_ip.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_ipv4.h \
 ../../../Middlewares/ST/netxduo/common/inc/nx_ipv6.h
../../../Middlewares/ST/netxduo/common/inc/nx_api.h:
../../../Middlewares/ST/threadx/ports/cortex_m55/gnu/inc/tx_port.h:
../../../FSBL/Core/Inc/tx_user.h:
../../../Middlewares/ST/threadx/common/inc/tx_api.h:
../../../Middlewares/ST/netxduo/ports/cortex_m55/gnu/inc/nx_port.h:
../../../FSBL/NetXDuo/App/nx_user.h:
../../../Middlewares/ST/threadx/common/inc/tx_trace.h:
../../../Middlewares/ST/netxduo/common/inc/nx_ipv6.h:
../../../Middlewares/ST/netxduo/common/inc/nx_api.h:
../../../Middlewares/ST/netxduo/common/inc/nx_icmpv6.h:
../../../Middlewares/ST/netxduo/common/inc/nx_nd_cache.h:
../../../Middlewares/ST/netxduo/common/inc/nx_ip.h:
../../../Middlewares/ST/netxduo/common/inc/nx_ipv4.h:
../../../Middlewares/ST/netxduo/common/inc/nx_ipv6.h:
