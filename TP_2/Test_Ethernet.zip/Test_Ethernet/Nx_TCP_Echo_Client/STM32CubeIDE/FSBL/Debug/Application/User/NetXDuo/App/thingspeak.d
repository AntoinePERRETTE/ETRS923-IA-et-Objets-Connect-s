Application/User/NetXDuo/App/thingspeak.o: \
 ../Application/User/NetXDuo/App/thingspeak.c \
 ../Application/User/NetXDuo/App/thingspeak.h
../Application/User/NetXDuo/App/thingspeak.h:
