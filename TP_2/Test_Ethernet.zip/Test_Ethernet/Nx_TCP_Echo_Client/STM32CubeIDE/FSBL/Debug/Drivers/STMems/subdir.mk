################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/STMems/lps22df_reg.c \
../Drivers/STMems/platform.c \
../Drivers/STMems/sht40ad1b_reg.c \
../Drivers/STMems/stts22h_reg.c 

OBJS += \
./Drivers/STMems/lps22df_reg.o \
./Drivers/STMems/platform.o \
./Drivers/STMems/sht40ad1b_reg.o \
./Drivers/STMems/stts22h_reg.o 

C_DEPS += \
./Drivers/STMems/lps22df_reg.d \
./Drivers/STMems/platform.d \
./Drivers/STMems/sht40ad1b_reg.d \
./Drivers/STMems/stts22h_reg.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/STMems/%.o Drivers/STMems/%.su Drivers/STMems/%.cyclo: ../Drivers/STMems/%.c Drivers/STMems/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m55 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32N657xx -DNX_INCLUDE_USER_DEFINE_FILE -DTX_INCLUDE_USER_DEFINE_FILE -DTX_SINGLE_MODE_SECURE=1 -c -I../../../Drivers/STM32N6xx_HAL_Driver/Inc -I../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include -I../../../Drivers/STM32N6xx_HAL_Driver/Inc/Legacy -I../../../Drivers/BSP/Components/lan8742 -I../../../Middlewares/ST/netxduo/addons/dhcp -I../../../Middlewares/ST/netxduo/tsn/inc -I../../../Middlewares/ST/netxduo/common/drivers/ethernet -I../../../Middlewares/ST/threadx/common/inc -I../../../Middlewares/ST/netxduo/common/inc -I../../../Middlewares/ST/netxduo/ports/cortex_m55/gnu/inc -I../../../Middlewares/ST/threadx/ports/cortex_m55/gnu/inc -I../../../Drivers/CMSIS/Include -I../../../FSBL/AZURE_RTOS/App -I../../../FSBL/NetXDuo/App -I../../../FSBL/NetXDuo/Target -I../../../FSBL/Core/Inc -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Drivers/STMems" -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Drivers" -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Middlewares" -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Middlewares/netxduo/addons" -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Middlewares/netxduo/addons/dns" -I"/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/STM32CubeIDE/FSBL/Application/User/NetXDuo/App" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -mcmse -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-STMems

clean-Drivers-2f-STMems:
	-$(RM) ./Drivers/STMems/lps22df_reg.cyclo ./Drivers/STMems/lps22df_reg.d ./Drivers/STMems/lps22df_reg.o ./Drivers/STMems/lps22df_reg.su ./Drivers/STMems/platform.cyclo ./Drivers/STMems/platform.d ./Drivers/STMems/platform.o ./Drivers/STMems/platform.su ./Drivers/STMems/sht40ad1b_reg.cyclo ./Drivers/STMems/sht40ad1b_reg.d ./Drivers/STMems/sht40ad1b_reg.o ./Drivers/STMems/sht40ad1b_reg.su ./Drivers/STMems/stts22h_reg.cyclo ./Drivers/STMems/stts22h_reg.d ./Drivers/STMems/stts22h_reg.o ./Drivers/STMems/stts22h_reg.su

.PHONY: clean-Drivers-2f-STMems

