Drivers/STMems/sht40ad1b_reg.o: ../Drivers/STMems/sht40ad1b_reg.c \
 ../Drivers/STMems/sht40ad1b_reg.h
../Drivers/STMems/sht40ad1b_reg.h:
