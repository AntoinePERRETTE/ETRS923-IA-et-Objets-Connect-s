Drivers/STMems/lps22df_reg.o: ../Drivers/STMems/lps22df_reg.c \
 ../Drivers/STMems/lps22df_reg.h
../Drivers/STMems/lps22df_reg.h:
