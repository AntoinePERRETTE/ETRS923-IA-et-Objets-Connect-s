Drivers/BSP/Components/lan8742.o: \
 /home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Drivers/BSP/Components/lan8742/lan8742.c \
 /home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Drivers/BSP/Components/lan8742/lan8742.h
/home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Drivers/BSP/Components/lan8742/lan8742.h:
