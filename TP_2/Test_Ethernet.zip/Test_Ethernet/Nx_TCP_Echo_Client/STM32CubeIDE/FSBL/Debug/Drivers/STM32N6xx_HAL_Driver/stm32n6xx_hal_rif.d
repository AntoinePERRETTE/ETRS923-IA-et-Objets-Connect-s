Drivers/STM32N6xx_HAL_Driver/stm32n6xx_hal_rif.o: \
 /home/perrettea/Documents/IA_et_Objets_Connectes/ETRS923-IA-et-Objets-Connect-s/Test_Ethernet/Nx_TCP_Echo_Client/Drivers/STM32N6xx_HAL_Driver/Src/stm32n6xx_hal_rif.c \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal.h \
 ../../../FSBL/Core/Inc/stm32n6xx_hal_conf.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rcc.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_def.h \
 ../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/stm32n6xx.h \
 ../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/stm32n657xx.h \
 ../../../Drivers/CMSIS/Include/core_cm55.h \
 ../../../Drivers/CMSIS/Include/cmsis_version.h \
 ../../../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../../Drivers/CMSIS/Include/m-profile/armv8m_mpu.h \
 ../../../Drivers/CMSIS/Include/m-profile/armv8m_pmu.h \
 ../../../Drivers/CMSIS/Include/m-profile/armv7m_cachel1.h \
 ../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/system_stm32n6xx.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_ll_bus.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_ll_rcc.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rcc_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_gpio.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_gpio_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rif.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_dma.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_dma_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_cortex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_eth.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_eth_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_exti.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_i2c.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_i2c_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_pwr.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_pwr_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_tim.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_tim_ex.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_uart.h \
 ../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_uart_ex.h
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal.h:
../../../FSBL/Core/Inc/stm32n6xx_hal_conf.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rcc.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_def.h:
../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/stm32n6xx.h:
../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/stm32n657xx.h:
../../../Drivers/CMSIS/Include/core_cm55.h:
../../../Drivers/CMSIS/Include/cmsis_version.h:
../../../Drivers/CMSIS/Include/cmsis_compiler.h:
../../../Drivers/CMSIS/Include/cmsis_gcc.h:
../../../Drivers/CMSIS/Include/m-profile/armv8m_mpu.h:
../../../Drivers/CMSIS/Include/m-profile/armv8m_pmu.h:
../../../Drivers/CMSIS/Include/m-profile/armv7m_cachel1.h:
../../../Drivers/CMSIS/Device/ST/STM32N6xx/Include/system_stm32n6xx.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_ll_bus.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_ll_rcc.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rcc_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_gpio.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_gpio_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_rif.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_dma.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_dma_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_cortex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_eth.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_eth_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_exti.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_i2c.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_i2c_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_pwr.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_pwr_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_tim.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_tim_ex.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_uart.h:
../../../Drivers/STM32N6xx_HAL_Driver/Inc/stm32n6xx_hal_uart_ex.h:
