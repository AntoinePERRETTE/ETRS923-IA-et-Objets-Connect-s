Drivers/STMems/stts22h_reg.o: ../Drivers/STMems/stts22h_reg.c \
 ../Drivers/STMems/stts22h_reg.h
../Drivers/STMems/stts22h_reg.h:
